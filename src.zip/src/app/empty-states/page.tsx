export default function Page() {
  return (
    <div className="bg-sand-50 text-ink antialiased">


      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">

        <div>
          <h1 className="text-2xl font-semibold mb-2">حالت‌های خالی و خطا</h1>
          <p className="text-sm text-ink-soft leading-relaxed max-w-2xl">
            فلسفه طراحی این صفحه ساده است: هیچ صفحه خالی یا خطایی نباید کاربر را در بن‌بست بگذارد. هر حالت، دلیل اتفاق را ساده توضیح می‌دهد و همیشه حداقل یک اقدام بعدی روشن پیش پای کاربر می‌گذارد — نه فقط پیام «مشکلی پیش آمد».
            هرکدام از بخش‌های زیر را می‌توانید مستقیماً در صفحه واقعی مربوطه کپی کنید.
          </p>
        </div>

        {/* <!-- ============ 1. 404 PAGE ============ --> */}
        <section className="border-t border-sand-200 pt-10">
          <p className="text-xs font-medium text-gold-600 mb-4">۱ · صفحه ۴۰۴</p>
          <div className="bg-sand-100/50 rounded-3xl p-8 sm:p-14 text-center">
            <svg width="100" height="100" viewBox="0 0 24 24" fill="none" className="mx-auto mb-6">
              <circle cx="12" cy="12" r="9" stroke="#E2D2AC" strokeWidth="1.2" />
              <path d="M9 10c.3-1 1-1.5 2-1.5S13 9 12.5 10 11 11.5 11 13" stroke="#B8863E" strokeWidth="1.3" stroke-linecap="round" />
              <circle cx="11" cy="16" r=".8" fill="#B8863E" />
            </svg>
            <p className="text-5xl font-light num text-ink-300 mb-3">۴۰۴</p>
            <h2 className="text-xl font-semibold mb-2">این صفحه پیدا نشد</h2>
            <p className="text-sm text-ink-soft max-w-sm mx-auto leading-relaxed mb-7">
              ممکن است آدرس اشتباه باشد یا این صفحه جابه‌جا شده باشد. نگران نباشید، از اینجا می‌توانید مسیر خود را ادامه دهید.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a href="index.html" className="inline-flex items-center justify-center gap-2 bg-emerald-800 hover:bg-emerald-700 text-sand-50 text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">بازگشت به خانه</a>
              <a href="category.html" className="inline-flex items-center justify-center gap-2 border border-sand-300 hover:border-ink text-ink text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">جست‌وجوی تالارها</a>
            </div>
          </div>
        </section>

        {/* <!-- ============ 2. NO SEARCH RESULTS ============ --> */}
        <section className="border-t border-sand-200 pt-10">
          <p className="text-xs font-medium text-gold-600 mb-4">۲ · جست‌وجوی بدون نتیجه</p>
          <div className="bg-sand-100/50 rounded-3xl p-8 sm:p-14 text-center">
            <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#E2D2AC" strokeWidth="1.2" className="mx-auto mb-6">
              <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /><path d="M8 11h6" stroke="#B8863E" />
            </svg>
            <h2 className="text-xl font-semibold mb-2">تالاری با این فیلترها پیدا نشد</h2>
            <p className="text-sm text-ink-soft max-w-sm mx-auto leading-relaxed mb-6">
              به نظر می‌رسد فیلترهای انتخابی محدودند. این گزینه‌ها را امتحان کنید:
            </p>
            <ul className="inline-flex flex-col gap-2 text-sm text-ink-soft mb-7 text-right">
              <li className="flex items-center gap-2"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1B3E32" strokeWidth="2"><path d="M20 6 9 17l-5-5" /></svg> شهر دیگری را امتحان کنید</li>
              <li className="flex items-center gap-2"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1B3E32" strokeWidth="2"><path d="M20 6 9 17l-5-5" /></svg> برخی فیلترها را حذف کنید</li>
              <li className="flex items-center gap-2"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1B3E32" strokeWidth="2"><path d="M20 6 9 17l-5-5" /></svg> محدوده بودجه را افزایش دهید</li>
            </ul>
            <div>
              <button className="bg-emerald-800 hover:bg-emerald-700 text-sand-50 text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">پاک‌کردن فیلترها</button>
            </div>
          </div>
        </section>

        {/* <!-- ============ 3. EMPTY FAVORITES ============ --> */}
        <section className="border-t border-sand-200 pt-10">
          <p className="text-xs font-medium text-gold-600 mb-4">۳ · علاقه‌مندی‌های خالی</p>
          <div className="bg-sand-100/50 rounded-3xl p-8 sm:p-14 text-center">
            <svg width="88" height="88" viewBox="0 0 24 24" fill="none" stroke="#E2D2AC" strokeWidth="1.1" className="mx-auto mb-6">
              <path d="M20.8 8.6c0-2.5-2-4.4-4.4-4.4-1.6 0-3.1.9-3.9 2.2A4.5 4.5 0 0 0 8.6 4.2c-2.5 0-4.4 2-4.4 4.4 0 5.2 8.3 10 8.3 10s8.3-4.8 8.3-10Z" stroke="#B8863E" />
            </svg>
            <h2 className="text-xl font-semibold mb-2">هنوز تالاری ذخیره نکرده‌اید</h2>
            <p className="text-sm text-ink-soft max-w-sm mx-auto leading-relaxed mb-7">
              هنگام مرور تالارها، روی نماد قلب بزنید تا گزینه‌های موردعلاقه‌تان اینجا جمع شوند.
            </p>
            <a href="category.html" className="inline-flex items-center gap-2 bg-emerald-800 hover:bg-emerald-700 text-sand-50 text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">مشاهده تالارها</a>
          </div>
        </section>

        {/* <!-- ============ 4. EMPTY CATEGORY ============ --> */}
        <section className="border-t border-sand-200 pt-10">
          <p className="text-xs font-medium text-gold-600 mb-4">۴ · دسته‌بندی خالی</p>
          <div className="bg-sand-100/50 rounded-3xl p-8 sm:p-14 text-center">
            <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#E2D2AC" strokeWidth="1.2" className="mx-auto mb-6">
              <rect x="4" y="7" width="16" height="13" rx="2" /><path d="M9 7V5a3 3 0 0 1 6 0v2" stroke="#B8863E" />
            </svg>
            <h2 className="text-xl font-semibold mb-2">هنوز تالاری در این دسته‌بندی ثبت نشده</h2>
            <p className="text-sm text-ink-soft max-w-sm mx-auto leading-relaxed mb-7">
              به‌زودی تالارهای بیشتری در این بخش اضافه می‌شوند. در همین حال می‌توانید سایر دسته‌بندی‌ها را مرور کنید.
            </p>
            <a href="index.html#categories" className="inline-flex items-center gap-2 bg-emerald-800 hover:bg-emerald-700 text-sand-50 text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">مشاهده دسته‌بندی‌ها</a>
          </div>
        </section>

        {/* <!-- ============ 5. LOADING SKELETONS ============ --> */}
        <section className="border-t border-sand-200 pt-10">
          <p className="text-xs font-medium text-gold-600 mb-4">۵ · اسکلت‌های بارگذاری</p>

          <p className="text-sm font-medium mb-3">کارت تالار</p>
          <div className="grid sm:grid-cols-3 gap-4 mb-8">
            <div className="bg-sand-50 rounded-3xl overflow-hidden shadow-soft">
              <div className="aspect-[4/3] skeleton"></div>
              <div className="p-5 space-y-3">
                <div className="h-4 w-3/4 rounded skeleton"></div>
                <div className="h-3 w-1/2 rounded skeleton"></div>
                <div className="h-8 w-full rounded-xl skeleton mt-3"></div>
              </div>
            </div>
            <div className="bg-sand-50 rounded-3xl overflow-hidden shadow-soft">
              <div className="aspect-[4/3] skeleton"></div>
              <div className="p-5 space-y-3">
                <div className="h-4 w-3/4 rounded skeleton"></div>
                <div className="h-3 w-1/2 rounded skeleton"></div>
                <div className="h-8 w-full rounded-xl skeleton mt-3"></div>
              </div>
            </div>
            <div className="bg-sand-50 rounded-3xl overflow-hidden shadow-soft hidden sm:block">
              <div className="aspect-[4/3] skeleton"></div>
              <div className="p-5 space-y-3">
                <div className="h-4 w-3/4 rounded skeleton"></div>
                <div className="h-3 w-1/2 rounded skeleton"></div>
                <div className="h-8 w-full rounded-xl skeleton mt-3"></div>
              </div>
            </div>
          </div>

          <p className="text-sm font-medium mb-3">گالری تصاویر</p>
          <div className="grid grid-cols-4 grid-rows-2 gap-2 h-56 rounded-3xl overflow-hidden mb-8">
            <div className="col-span-2 row-span-2 skeleton"></div>
            <div className="skeleton"></div>
            <div className="skeleton"></div>
            <div className="skeleton"></div>
            <div className="skeleton"></div>
          </div>

          <p className="text-sm font-medium mb-3">جزئیات تالار</p>
          <div className="space-y-3 mb-8 max-w-md">
            <div className="h-6 w-2/3 rounded skeleton"></div>
            <div className="h-4 w-1/2 rounded skeleton"></div>
            <div className="h-24 w-full rounded-xl skeleton"></div>
          </div>

          <p className="text-sm font-medium mb-3">نتایج جست‌وجو (ردیفی)</p>
          <div className="space-y-3 mb-8">
            <div className="flex items-center gap-4">
              <div className="w-20 h-16 rounded-xl skeleton shrink-0"></div>
              <div className="flex-1 space-y-2">
                <div className="h-3.5 w-1/3 rounded skeleton"></div>
                <div className="h-3 w-1/4 rounded skeleton"></div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-20 h-16 rounded-xl skeleton shrink-0"></div>
              <div className="flex-1 space-y-2">
                <div className="h-3.5 w-1/3 rounded skeleton"></div>
                <div className="h-3 w-1/4 rounded skeleton"></div>
              </div>
            </div>
          </div>

          <p className="text-sm font-medium mb-3">جدول</p>
          <div className="rounded-2xl overflow-hidden border border-sand-200">
            <div className="grid grid-cols-4 gap-4 p-4 border-b border-sand-200">
              <div className="h-3 rounded skeleton"></div><div className="h-3 rounded skeleton"></div><div className="h-3 rounded skeleton"></div><div className="h-3 rounded skeleton"></div>
            </div>
            <div className="grid grid-cols-4 gap-4 p-4 border-b border-sand-200">
              <div className="h-3 rounded skeleton"></div><div className="h-3 rounded skeleton"></div><div className="h-3 rounded skeleton"></div><div className="h-3 rounded skeleton"></div>
            </div>
          </div>
        </section>

        {/* ============ 6. GENERIC ERROR ============ */}
        <section className="border-t border-sand-200 pt-10">
          <p className="text-xs font-medium text-gold-600 mb-4">۶ · خطای عمومی</p>
          <div className="bg-sand-100/50 rounded-3xl p-8 sm:p-14 text-center">
            <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#E2D2AC" strokeWidth="1.2" className="mx-auto mb-6">
              <circle cx="12" cy="12" r="9" /><path d="M12 8v5" stroke="#8A2A38" /><circle cx="12" cy="16" r=".8" fill="#8A2A38" stroke="none" />
            </svg>
            <h2 className="text-xl font-semibold mb-2">مشکلی پیش آمد</h2>
            <p className="text-sm text-ink-soft max-w-sm mx-auto leading-relaxed mb-7">
              دریافت اطلاعات با خطا مواجه شد. لطفاً دوباره تلاش کنید؛ اگر مشکل ادامه داشت، با پشتیبانی در تماس باشید.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button className="inline-flex items-center justify-center gap-2 bg-emerald-800 hover:bg-emerald-700 text-sand-50 text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12a9 9 0 1 1-2.6-6.4M21 4v5h-5" /></svg>
                تلاش دوباره
              </button>
              <a href="index.html" className="inline-flex items-center justify-center gap-2 border border-sand-300 hover:border-ink text-ink text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">بازگشت به خانه</a>
              <a href="contact.html" className="inline-flex items-center justify-center gap-2 border border-sand-300 hover:border-ink text-ink text-sm font-medium px-6 py-3 rounded-full transition-colors focus-ring">تماس با پشتیبانی</a>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
